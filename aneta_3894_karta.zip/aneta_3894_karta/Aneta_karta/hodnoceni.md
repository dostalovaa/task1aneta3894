Ahoj,
posílám hodnocení tvého projektu.
Stránka vypadá graficky pěkně - barevně sladěná, dá se v ní vyznat + zajímavé boty samozřejmě ;)

Co se týče **html kódu**: moc pěkný, oceňuji hlavně rozdělení do divů -> dá se v tom orientovat. Pro ještě trochu lepší přehlednost jsem ti tam přidala pár prádzných řádků (tak, aby bylo lépe vidět, co k sobě patří a co už ne). Asi jediné čím, by to šlo ještě vylepšit je použití sémantických elementů jako je \<section>, \<header> atp. (víc si o nich může přečíst v Extra materiálech).

Co se týče **css kódu**: Super, že používáš proměnné na uložení jednotlivých barev. Celkově je napsaný dobře - docela zevrubně jsem ho prošla a řešial jsem tam spíš maličkosti. ;)

Kdybys měla nějaké otázky, tak se určitě zeptej a jinak se měj hezky
Anička
